#!/usr/bin/env node

// If NODE_ENV is production, run the production server
if (process.env.NODE_ENV === 'production') {
  console.log('🚀 Starting in PRODUCTION mode');
  require('child_process').execSync('node dist/index.cjs', { stdio: 'inherit' });
} else {
  // Otherwise run dev
  console.log('🔧 Starting in DEVELOPMENT mode');
  require('child_process').execSync('NODE_ENV=development tsx server/index.ts', { stdio: 'inherit' });
}
