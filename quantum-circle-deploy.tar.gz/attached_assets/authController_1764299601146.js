// backend/src/controllers/authController.js
const { db } = require("../services/firebaseAdmin");

/**
 * createProfile
 * Body: { name?: string, avatarUrl?: string, interests?: [string] }
 * Authenticated endpoint (req.user provided by middleware)
 */
async function createProfile(req, res) {
  try {
    const uid = req.user.uid;
    const { name, avatarUrl, interests } = req.body;

    const userRef = db.collection("users").doc(uid);
    const snapshot = await userRef.get();

    const data = {
      name: name || req.user.name || req.user.email?.split("@")[0] || "User",
      email: req.user.email || null,
      avatarUrl: avatarUrl || null,
      interests: Array.isArray(interests) ? interests : [],
      points: snapshot.exists ? (snapshot.data().points || 0) : 0,
      updatedAt: adminTimestamp()
    };

    await userRef.set(data, { merge: true });
    const doc = await userRef.get();
    return res.json({ ok: true, user: { id: doc.id, ...doc.data() } });
  } catch (err) {
    console.error("createProfile error:", err);
    return res.status(500).json({ error: "server_error" });
  }
}

/**
 * getProfile - returns doc for authenticated user
 */
async function getProfile(req, res) {
  try {
    const uid = req.user.uid;
    const doc = await db.collection("users").doc(uid).get();
    if (!doc.exists) return res.status(404).json({ error: "not_found" });
    return res.json({ ok: true, user: { id: doc.id, ...doc.data() } });
  } catch (err) {
    console.error("getProfile error:", err);
    return res.status(500).json({ error: "server_error" });
  }
}

/* helper for server timestamp without importing admin every file */
const { admin } = require("../services/firebaseAdmin");
function adminTimestamp() {
  return admin.firestore.FieldValue.serverTimestamp();
}

module.exports = { createProfile, getProfile };
