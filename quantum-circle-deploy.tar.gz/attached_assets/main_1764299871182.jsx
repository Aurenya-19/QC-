import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { AppProvider } from "./context/AppContext";
import { ChatProvider } from "./context/ChatContext";
import { AuraProvider } from "./context/AuraContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthProvider>
      <AppProvider>
        <ChatProvider>
          <AuraProvider>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </AuraProvider>
        </ChatProvider>
      </AppProvider>
    </AuthProvider>
  </React.StrictMode>
);
