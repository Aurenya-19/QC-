// backend/src/controllers/chatController.js
const { db } = require("../services/firebaseAdmin");

/**
 * sendMessage
 * body: { communityId, text }
 * requires auth
 */
async function sendMessage(req, res) {
  try {
    const uid = req.user.uid;
    const { communityId, text } = req.body;
    if (!text || !text.trim()) return res.status(400).json({ error: "text_required" });
    if (!communityId) return res.status(400).json({ error: "community_required" });

    const message = {
      communityId,
      fromUser: uid,
      text: text.trim(),
      createdAt: adminTimestamp()
    };

    const ref = await db.collection("messages").add(message);
    return res.json({ ok: true, id: ref.id, message });
  } catch (err) {
    console.error("sendMessage error:", err);
    return res.status(500).json({ error: "server_error" });
  }
}

/**
 * listMessages
 * params: communityId
 */
async function listMessages(req, res) {
  try {
    const { communityId } = req.params;
    if (!communityId) return res.status(400).json({ error: "community_required" });

    const snap = await db.collection("messages")
      .where("communityId", "==", communityId)
      .orderBy("createdAt", "asc")
      .limit(500)
      .get();

    const msgs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    return res.json({ ok: true, messages: msgs });
  } catch (err) {
    console.error("listMessages error:", err);
    return res.status(500).json({ error: "server_error" });
  }
}

const { admin } = require("../services/firebaseAdmin");
function adminTimestamp() {
  return admin.firestore.FieldValue.serverTimestamp();
}

module.exports = { sendMessage, listMessages };
