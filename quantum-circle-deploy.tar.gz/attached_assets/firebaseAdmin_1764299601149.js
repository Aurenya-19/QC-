// backend/src/services/firebaseAdmin.js
const admin = require("firebase-admin");
const path = require("path");
require("dotenv").config();

const servicePath = process.env.SERVICE_ACCOUNT_PATH || process.env.GOOGLE_APPLICATION_CREDENTIALS;
if (!servicePath) {
  console.error("ERROR: Set SERVICE_ACCOUNT_PATH or GOOGLE_APPLICATION_CREDENTIALS env var to service account JSON path.");
  process.exit(1);
}

const serviceAccount = require(path.resolve(servicePath));

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    storageBucket: `${process.env.FIREBASE_PROJECT_ID || serviceAccount.project_id}.appspot.com`
  });
}

const db = admin.firestore();
const auth = admin.auth();
const bucket = admin.storage().bucket();

module.exports = { admin, db, auth, bucket };
