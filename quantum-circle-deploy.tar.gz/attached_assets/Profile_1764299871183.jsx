import React from "react";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth } from "../utils/firebase";

const Profile = () => {
  const [user] = useAuthState(auth);

  return (
    <div className="flex bg-gray-50 min-h-screen">
      <Sidebar />
      <div className="flex-1 p-6">
        <Navbar />
        <h1 className="text-2xl font-bold mb-4">Profile</h1>
        {user && (
          <div className="bg-white p-6 rounded-lg shadow-md w-96">
            <p className="mb-2"><strong>Name:</strong> {user.displayName || "User"}</p>
            <p className="mb-2"><strong>Email:</strong> {user.email}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
