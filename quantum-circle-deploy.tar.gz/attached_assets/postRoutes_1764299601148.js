// backend/src/routes/postRoutes.js
const express = require("express");
const router = express.Router();
const verifyFirebaseToken = require("../middleware/authMiddleware");
const { createPost, listPosts, getPost } = require("../controllers/postController");

// public list
router.get("/", listPosts);

// create post (auth)
router.post("/create", verifyFirebaseToken, createPost);

// get single post
router.get("/:id", getPost);

module.exports = router;
