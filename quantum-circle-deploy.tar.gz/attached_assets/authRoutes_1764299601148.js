// backend/src/routes/authRoutes.js
const express = require("express");
const router = express.Router();
const { createProfile, getProfile } = require("../controllers/authController");
const verifyFirebaseToken = require("../middleware/authMiddleware");

// create profile (can be called after frontend user signs up/logs in)
router.post("/profile", verifyFirebaseToken, createProfile);

// get own profile
router.get("/me", verifyFirebaseToken, getProfile);

module.exports = router;
