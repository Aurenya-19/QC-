import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getFunctions } from "firebase/functions";

const firebaseConfig = {
  apiKey: "XXXX",
  authDomain: "quantumcircle-70ae2.firebaseapp.com",
  projectId: "quantumcircle-70ae2",
  storageBucket: "quantumcircle-70ae2.firebasestorage.app",
  messagingSenderId: "934550358176",
  appId: "1:934550358176:web:abcd1234"   
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const functions = getFunctions(app);
