// backend/src/middleware/authMiddleware.js
const { auth } = require("../services/firebaseAdmin");

/**
 * Expects header: Authorization: Bearer <idToken>
 * Adds req.user = decodedToken (contains uid, email, etc.)
 */
async function verifyFirebaseToken(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const match = header.match(/^Bearer (.*)$/);
    if (!match) {
      return res.status(401).json({ error: "Missing Authorization header" });
    }
    const idToken = match[1];
    const decoded = await auth.verifyIdToken(idToken);
    req.user = decoded;
    return next();
  } catch (err) {
    console.error("Token verify failed:", err.message || err);
    return res.status(401).json({ error: "Unauthorized" });
  }
}

module.exports = verifyFirebaseToken;
