// backend/src/routes/chatRoutes.js
const express = require("express");
const router = express.Router();
const verifyFirebaseToken = require("../middleware/authMiddleware");
const { sendMessage, listMessages } = require("../controllers/chatController");

// send message (auth)
router.post("/send", verifyFirebaseToken, sendMessage);

// list messages for a community (public)
router.get("/history/:communityId", listMessages);

module.exports = router;
