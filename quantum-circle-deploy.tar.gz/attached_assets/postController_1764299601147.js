// backend/src/controllers/postController.js
const { db } = require("../services/firebaseAdmin");

/**
 * createPost
 * body: { content, communityId?, mediaUrl? }
 * requires auth
 */
async function createPost(req, res) {
  try {
    const uid = req.user.uid;
    const { content, communityId = null, mediaUrl = null } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ error: "content_required" });
    }

    const post = {
      userId: uid,
      content: content.trim(),
      communityId: communityId || null,
      mediaUrl: mediaUrl || null,
      likes: 0,
      commentsCount: 0,
      createdAt: adminTimestamp()
    };

    const ref = await db.collection("posts").add(post);
    const doc = await ref.get();
    return res.json({ ok: true, post: { id: doc.id, ...doc.data() } });
  } catch (err) {
    console.error("createPost error:", err);
    return res.status(500).json({ error: "server_error" });
  }
}

/**
 * listPosts
 * query params: ?communityId=...&limit=20
 */
async function listPosts(req, res) {
  try {
    const { communityId } = req.query;
    let q = db.collection("posts").orderBy("createdAt", "desc").limit(50);
    if (communityId) q = db.collection("posts").where("communityId", "==", communityId).orderBy("createdAt", "desc").limit(50);
    const snap = await q.get();
    const posts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    return res.json({ ok: true, posts });
  } catch (err) {
    console.error("listPosts error:", err);
    return res.status(500).json({ error: "server_error" });
  }
}

/**
 * getPost
 */
async function getPost(req, res) {
  try {
    const id = req.params.id;
    const doc = await db.collection("posts").doc(id).get();
    if (!doc.exists) return res.status(404).json({ error: "not_found" });
    return res.json({ ok: true, post: { id: doc.id, ...doc.data() } });
  } catch (err) {
    console.error("getPost error:", err);
    return res.status(500).json({ error: "server_error" });
  }
}

const { admin } = require("../services/firebaseAdmin");
function adminTimestamp() {
  return admin.firestore.FieldValue.serverTimestamp();
}

module.exports = { createPost, listPosts, getPost };
