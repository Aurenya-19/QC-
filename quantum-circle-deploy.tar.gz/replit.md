# Quantum Circle - PWA Platform

## Project Overview
Quantum Circle is a full-stack social platform with cyberpunk/sci-fi aesthetic for youth developers to discover technologies, collaborate on projects, and compete on leaderboards. Now deployed as a Progressive Web App (PWA).

## Current Status
✅ **Complete & Deployed**
- Full-stack implementation with Express.js backend and React frontend
- PostgreSQL database integrated
- PWA capabilities enabled for mobile installation
- Production build optimized and ready

## PWA Features Added
- **manifest.json** - App metadata for installation on mobile devices
- **service-worker.js** - Offline support and caching strategy
- **Meta tags** in index.html for iOS/Android installation
- **Shortcuts** for quick access to Feed, Bounties, Communities sections

## Installation Instructions

### Android (Chrome)
1. Visit: https://code-fix-launch--ritikaa199110.replit.app/
2. Wait 3-5 seconds for install prompt
3. Tap "Install" when popup appears
4. App installs to home screen

### iPhone/iPad (Safari)
1. Visit: https://code-fix-launch--ritikaa199110.replit.app/
2. Tap Share (⬆️) at bottom
3. Tap "Add to Home Screen"
4. Tap "Add" to install

## Tech Stack
- **Frontend**: React 19, Vite, TailwindCSS, Radix UI
- **Backend**: Express.js, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with cyberpunk theme (neon cyan/purple, Orbitron/Rajdhani fonts)
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation

## Architecture
- `client/` - React frontend application
- `server/` - Express.js backend with API routes
- `shared/` - Shared types and schemas (Drizzle + Zod)
- `dist/` - Production build (frontend + bundled server)

## Build & Deployment
- **Development**: `npm run dev` - Runs on http://localhost:5000
- **Production Build**: `npm run build` - Creates optimized dist/ folder
- **Production Start**: `npm run start` - Serves production build

## Key Features
✨ Social feed with posts and engagement
⚡ Bounty system for developer tasks  
🌐 Community discovery and collaboration
📊 Leaderboards (segmented categories)
🔒 Session-based authentication
📱 Full PWA installation support
🌙 Cyberpunk UI with theme colors

## User Constraints Considered
- Simple, non-over-engineered implementation as requested
- No paid services required (uses PostgreSQL, no external APIs)
- Suitable for deployment on Replit's free tier
- Mobile-friendly design for orphanage environment

## Important Files
- `client/public/manifest.json` - PWA manifest
- `client/public/service-worker.js` - Offline caching
- `client/index.html` - PWA meta tags
- `server/static.ts` - Static file serving configuration
- `server/routes.ts` - API endpoints
- `shared/schema.ts` - Database schema and types
